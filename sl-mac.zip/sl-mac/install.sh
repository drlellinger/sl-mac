sudo su
cp sl /usr/local/bin
chmod a+x /usr/local/bin/sl
