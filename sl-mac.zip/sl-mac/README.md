sl-mac
======

Port Masashi Toyoda's SL (Steam Locomotive) to macOS


# Install Steps

## Clone

```bash
$ git clone https://github.com/drlellinger/sl-mac
```

## Install

```bash
$ cd sl-mac
$ sudo chmod +x install.sh
```

## Usage

```bash
$ sl
$ sl-l
$ sl-h
```
